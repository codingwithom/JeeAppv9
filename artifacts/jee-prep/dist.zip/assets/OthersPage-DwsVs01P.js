import { c as createLucideIcon, aK as useLocation, r as reactExports, O as idbGet, Q as idbSet, j as jsxRuntimeExports, B as Button, y as ArrowLeft, S as Search, I as Input, C as Card, f as Check, a4 as BookOpen, p as ChevronDown, h as ChevronRight, a6 as Layers } from "./index-C1khQ5tq.js";
import { Q as QuestionsPage, F as FileQuestionMark } from "./QuestionsPage-C9oJ-uIR.js";
import { F as Flame } from "./flame-Bxgt_Jew.js";
import { R as RotateCcw } from "./rotate-ccw-Bpcqx8eQ.js";
import { L as ListTodo } from "./list-todo-Cy8ETtbe.js";
import { A as ArrowRight } from "./katex-vxCDRUD3.js";
import "./circle-alert-C9XCA1jT.js";
import "./clock-DyEQ_2jZ.js";
import "./circle-check-DmzBbfdK.js";
const __iconNode = [
  ["path", { d: "M16 7h6v6", key: "box55l" }],
  ["path", { d: "m22 7-8.5 8.5-5-5L2 17", key: "1t1m79" }]
];
const TrendingUp = createLucideIcon("trending-up", __iconNode);
const DEFAULT_PW_BATCHES = [
  {
    id: "arjuna-jee-2026",
    name: "Arjuna JEE 2026",
    target: "Class 11 (JEE Main & Advanced 2027)",
    description: "Complete foundational Class 11 curriculum with theory lectures and daily problem sheets (DPPs).",
    subjects: [
      {
        name: "Physics",
        faculty: "Rajwant Sir & Saleem Sir",
        chapters: [
          {
            id: "arj-phy-1",
            title: "Units, Dimensions & Measurements",
            lectures: [
              { id: "arj-phy-1-1", title: "Lec 01: Physical Quantities, Fundamental & Derived Units", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-1-2", title: "Lec 02: Dimensional Formulae & Principle of Homogeneity", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-1-3", title: "Lec 03: Applications of Dimensional Analysis & Limitations", type: "lecture", duration: "1h 40m" },
              { id: "arj-phy-1-4", title: "Lec 04: Errors in Measurement, Vernier Calliper & Screw Gauge", type: "lecture", duration: "2h 00m" },
              { id: "arj-phy-1-dpp1", title: "DPP 01: Units & Dimensions (20 Questions)", type: "dpp", duration: "45m" },
              { id: "arj-phy-1-dpp2", title: "DPP 02: Errors & Instruments Analysis (25 Questions)", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "arj-phy-2",
            title: "Mathematical Tools & Vectors",
            lectures: [
              { id: "arj-phy-2-1", title: "Lec 01: Coordinate Systems, Trigonometry & Graphs", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-2-2", title: "Lec 02: Differentiation Basics & Maxima/Minima", type: "lecture", duration: "1h 55m" },
              { id: "arj-phy-2-3", title: "Lec 03: Integration Fundamentals & Definite Integrals in Physics", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-2-4", title: "Lec 04: Vector Addition, Triangle Law & Parallelogram Law", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-2-5", title: "Lec 05: Resolution of Vectors & Unit Vectors in 2D/3D", type: "lecture", duration: "1h 40m" },
              { id: "arj-phy-2-6", title: "Lec 06: Dot Product, Cross Product & Applications", type: "lecture", duration: "1h 55m" },
              { id: "arj-phy-2-dpp1", title: "DPP 01: Basic Calculus in Physics", type: "dpp", duration: "40m" },
              { id: "arj-phy-2-dpp2", title: "DPP 02: Vector Algebra & Products", type: "dpp", duration: "45m" }
            ]
          },
          {
            id: "arj-phy-3",
            title: "Motion in a Straight Line (Kinematics 1D)",
            lectures: [
              { id: "arj-phy-3-1", title: "Lec 01: Distance, Displacement, Average Speed & Velocity", type: "lecture", duration: "1h 40m" },
              { id: "arj-phy-3-2", title: "Lec 02: Instantaneous Velocity, Acceleration & Calculus Problems", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-3-3", title: "Lec 03: Equations of Motion for Uniform Acceleration", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-3-4", title: "Lec 04: Motion Under Gravity & Stopping Distance", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-3-5", title: "Lec 05: Motion Graphs (s-t, v-t, a-t Transformation)", type: "lecture", duration: "2h 05m" },
              { id: "arj-phy-3-dpp1", title: "DPP 01: Uniform & Non-Uniform 1D Motion", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "arj-phy-4",
            title: "Motion in a Plane (Kinematics 2D & Projectile)",
            lectures: [
              { id: "arj-phy-4-1", title: "Lec 01: 2D Kinematics Equations & Position Vectors", type: "lecture", duration: "1h 40m" },
              { id: "arj-phy-4-2", title: "Lec 02: Ground to Ground Projectile Motion & Formulae", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-4-3", title: "Lec 03: Equation of Trajectory & Radius of Curvature", type: "lecture", duration: "1h 55m" },
              { id: "arj-phy-4-4", title: "Lec 04: Horizontal Projectile & Projection from a Tower", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-4-5", title: "Lec 05: Projectile on an Inclined Plane", type: "lecture", duration: "2h 00m" },
              { id: "arj-phy-4-6", title: "Lec 06: Relative Motion in 1D & River-Boat Problems", type: "lecture", duration: "2h 10m" },
              { id: "arj-phy-4-7", title: "Lec 07: Rain-Man Problems & Aircraft Wind Problems", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-4-dpp1", title: "DPP 01: Projectile Motion Problems", type: "dpp", duration: "45m" },
              { id: "arj-phy-4-dpp2", title: "DPP 02: Relative Motion in 2D", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "arj-phy-5",
            title: "Newton's Laws of Motion (NLM) & Friction",
            lectures: [
              { id: "arj-phy-5-1", title: "Lec 01: Inertia, Momentum & Newton's Second Law", type: "lecture", duration: "1h 45m" },
              { id: "arj-phy-5-2", title: "Lec 02: Free Body Diagrams (FBD) & Normal Reaction", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-5-3", title: "Lec 03: Tension in Strings & Smooth Pulley Systems", type: "lecture", duration: "1h 55m" },
              { id: "arj-phy-5-4", title: "Lec 04: Constrained Motion (String & Wedge Constraints)", type: "lecture", duration: "2h 05m" },
              { id: "arj-phy-5-5", title: "Lec 05: Pseudo Force & Non-Inertial Reference Frames", type: "lecture", duration: "1h 50m" },
              { id: "arj-phy-5-6", title: "Lec 06: Friction Fundamentals, Static vs Kinetic Friction", type: "lecture", duration: "1h 55m" },
              { id: "arj-phy-5-7", title: "Lec 07: Two-Block Problems & Critical Acceleration", type: "lecture", duration: "2h 15m" },
              { id: "arj-phy-5-dpp1", title: "DPP 01: Pulley & Constraint Problems", type: "dpp", duration: "50m" },
              { id: "arj-phy-5-dpp2", title: "DPP 02: Friction & Multi-Block Systems", type: "dpp", duration: "55m" }
            ]
          }
        ]
      },
      {
        name: "Chemistry",
        faculty: "Amit Mahajan Sir & Pankaj Sir",
        chapters: [
          {
            id: "arj-chem-1",
            title: "Some Basic Concepts of Chemistry (Mole Concept)",
            lectures: [
              { id: "arj-chem-1-1", title: "Lec 01: Introduction, Matter Classification & Laws of Chemical Combination", type: "lecture", duration: "1h 45m" },
              { id: "arj-chem-1-2", title: "Lec 02: Mole Definition, Atomic & Molecular Masses, Avogadro Number", type: "lecture", duration: "1h 50m" },
              { id: "arj-chem-1-3", title: "Lec 03: Percentage Composition, Empirical & Molecular Formula", type: "lecture", duration: "1h 45m" },
              { id: "arj-chem-1-4", title: "Lec 04: Stoichiometry & Limiting Reagent Concept", type: "lecture", duration: "2h 00m" },
              { id: "arj-chem-1-5", title: "Lec 05: Concentration Terms (Molarity, Molality, Mole Fraction, ppm)", type: "lecture", duration: "2h 10m" },
              { id: "arj-chem-1-dpp1", title: "DPP 01: Mole Concept & Limiting Reagent", type: "dpp", duration: "45m" },
              { id: "arj-chem-1-dpp2", title: "DPP 02: Concentration Terms & Mixing Problems", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "arj-chem-2",
            title: "Structure of Atom",
            lectures: [
              { id: "arj-chem-2-1", title: "Lec 01: Subatomic Particles & Rutherford Nuclear Model", type: "lecture", duration: "1h 40m" },
              { id: "arj-chem-2-2", title: "Lec 02: Electromagnetic Radiations & Planck's Quantum Theory", type: "lecture", duration: "1h 50m" },
              { id: "arj-chem-2-3", title: "Lec 03: Photoelectric Effect & Dual Nature of Light", type: "lecture", duration: "1h 45m" },
              { id: "arj-chem-2-4", title: "Lec 04: Bohr's Model of Hydrogen Atom & Line Spectrum", type: "lecture", duration: "2h 00m" },
              { id: "arj-chem-2-5", title: "Lec 05: De Broglie Hypothesis & Heisenberg Uncertainty Principle", type: "lecture", duration: "1h 50m" },
              { id: "arj-chem-2-6", title: "Lec 06: Quantum Numbers (n, l, m, s) & Orbitals Shapes", type: "lecture", duration: "2h 05m" },
              { id: "arj-chem-2-7", title: "Lec 07: Aufbau Principle, Pauli Exclusion & Hund's Rule", type: "lecture", duration: "1h 45m" },
              { id: "arj-chem-2-dpp1", title: "DPP 01: Quantum Theory & Bohr Model", type: "dpp", duration: "45m" },
              { id: "arj-chem-2-dpp2", title: "DPP 02: Quantum Numbers & Electronic Configuration", type: "dpp", duration: "45m" }
            ]
          }
        ]
      },
      {
        name: "Mathematics",
        faculty: "Sachin Sir & Ashish Agarwal Sir",
        chapters: [
          {
            id: "arj-math-1",
            title: "Sets, Relations & Functions",
            lectures: [
              { id: "arj-math-1-1", title: "Lec 01: Set Representation, Subsets & Power Set", type: "lecture", duration: "1h 45m" },
              { id: "arj-math-1-2", title: "Lec 02: Set Operations, Venn Diagrams & Cardinality Problems", type: "lecture", duration: "1h 50m" },
              { id: "arj-math-1-3", title: "Lec 03: Cartesian Product & Relations (Reflexive, Symmetric, Transitive)", type: "lecture", duration: "2h 00m" },
              { id: "arj-math-1-4", title: "Lec 04: Functions Definition, Domain & Range", type: "lecture", duration: "2h 10m" },
              { id: "arj-math-1-5", title: "Lec 05: Classification of Functions (One-One, Onto, Bijective)", type: "lecture", duration: "1h 55m" },
              { id: "arj-math-1-dpp1", title: "DPP 01: Equivalence Relations & Cardinality", type: "dpp", duration: "45m" },
              { id: "arj-math-1-dpp2", title: "DPP 02: Domain & Range Calculation", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "arj-math-2",
            title: "Trigonometric Functions & Identities",
            lectures: [
              { id: "arj-math-2-1", title: "Lec 01: Angle Measurement (Degrees & Radians), Unit Circle", type: "lecture", duration: "1h 45m" },
              { id: "arj-math-2-2", title: "Lec 02: Compound Angle Formulae (sin(A±B), cos(A±B))", type: "lecture", duration: "1h 55m" },
              { id: "arj-math-2-3", title: "Lec 03: Transformation Formulae (Product into Sum & Vice Versa)", type: "lecture", duration: "1h 50m" },
              { id: "arj-math-2-4", title: "Lec 04: Multiple & Submultiple Angles (2A, 3A, A/2)", type: "lecture", duration: "2h 00m" },
              { id: "arj-math-2-5", title: "Lec 05: Trigonometric Equations & General Solutions", type: "lecture", duration: "2h 10m" },
              { id: "arj-math-2-dpp1", title: "DPP 01: Trigonometric Identities & Simplification", type: "dpp", duration: "45m" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "lakshya-jee-2026",
    name: "Lakshya JEE 2026",
    target: "Class 12 (JEE Main & Advanced 2026)",
    description: "Complete Class 12 syllabus coverage with advanced problem solving and board synchronization.",
    subjects: [
      {
        name: "Physics",
        faculty: "Saleem Sir & Rajwant Sir",
        chapters: [
          {
            id: "lak-phy-1",
            title: "Electrostatics & Electric Field",
            lectures: [
              { id: "lak-phy-1-1", title: "Lec 01: Electric Charges & Coulomb's Law in Vector Form", type: "lecture", duration: "1h 50m" },
              { id: "lak-phy-1-2", title: "Lec 02: Electric Field & Principle of Superposition", type: "lecture", duration: "1h 55m" },
              { id: "lak-phy-1-3", title: "Lec 03: Electric Dipole, Torque & Potential Energy", type: "lecture", duration: "1h 45m" },
              { id: "lak-phy-1-4", title: "Lec 04: Gauss's Law & Electric Flux Calculations", type: "lecture", duration: "2h 10m" },
              { id: "lak-phy-1-5", title: "Lec 05: Applications of Gauss's Law (Symmetric Distributions)", type: "lecture", duration: "2h 00m" },
              { id: "lak-phy-1-dpp1", title: "DPP 01: Coulomb's Law & Superposition", type: "dpp", duration: "50m" },
              { id: "lak-phy-1-dpp2", title: "DPP 02: Gauss's Law & Flux Applications", type: "dpp", duration: "50m" }
            ]
          },
          {
            id: "lak-phy-2",
            title: "Current Electricity",
            lectures: [
              { id: "lak-phy-2-1", title: "Lec 01: Drift Velocity, Mobility & Ohm's Law Derivation", type: "lecture", duration: "1h 45m" },
              { id: "lak-phy-2-2", title: "Lec 02: Resistance Combinations & Color Coding", type: "lecture", duration: "1h 40m" },
              { id: "lak-phy-2-3", title: "Lec 03: Kirchhoff's Current & Voltage Laws (KCL & KVL)", type: "lecture", duration: "2h 05m" },
              { id: "lak-phy-2-4", title: "Lec 04: Nodal Analysis & Symmetry in Resistor Circuits", type: "lecture", duration: "2h 15m" },
              { id: "lak-phy-2-5", title: "Lec 05: Potentiometer, Meter Bridge & Galvanometer Conversion", type: "lecture", duration: "2h 00m" },
              { id: "lak-phy-2-dpp1", title: "DPP 01: Kirchhoff's Laws & Complex Circuits", type: "dpp", duration: "50m" }
            ]
          }
        ]
      },
      {
        name: "Chemistry",
        faculty: "Pankaj Sir & Faisal Sir",
        chapters: [
          {
            id: "lak-chem-1",
            title: "Solutions & Colligative Properties",
            lectures: [
              { id: "lak-chem-1-1", title: "Lec 01: Types of Solutions & Henry's Law Applications", type: "lecture", duration: "1h 45m" },
              { id: "lak-chem-1-2", title: "Lec 02: Raoult's Law for Volatile & Non-Volatile Solutes", type: "lecture", duration: "1h 55m" },
              { id: "lak-chem-1-3", title: "Lec 03: Ideal & Non-Ideal Solutions, Azeotropes", type: "lecture", duration: "1h 50m" },
              { id: "lak-chem-1-4", title: "Lec 04: Colligative Properties (RLVP, Elevation in BP, Depression in FP)", type: "lecture", duration: "2h 15m" },
              { id: "lak-chem-1-5", title: "Lec 05: Osmotic Pressure & Van't Hoff Factor (i)", type: "lecture", duration: "2h 00m" },
              { id: "lak-chem-1-dpp1", title: "DPP 01: Raoult's Law & Colligative Properties", type: "dpp", duration: "45m" }
            ]
          }
        ]
      },
      {
        name: "Mathematics",
        faculty: "Sachin Sir & Ashish Sir",
        chapters: [
          {
            id: "lak-math-1",
            title: "Continuity, Differentiability & Limits",
            lectures: [
              { id: "lak-math-1-1", title: "Lec 01: Limits Recap, L'Hopital's Rule & Expansions", type: "lecture", duration: "1h 50m" },
              { id: "lak-math-1-2", title: "Lec 02: Continuity at a Point & in an Interval", type: "lecture", duration: "1h 55m" },
              { id: "lak-math-1-3", title: "Lec 03: Intermediate Value Theorem & Types of Discontinuity", type: "lecture", duration: "1h 45m" },
              { id: "lak-math-1-4", title: "Lec 04: Differentiability & Geometrical Significance", type: "lecture", duration: "2h 05m" },
              { id: "lak-math-1-dpp1", title: "DPP 01: Continuity & Differentiability", type: "dpp", duration: "50m" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "prayas-jee-2026",
    name: "Prayas JEE 2026 (Droppers)",
    target: "Droppers / Repeaters (JEE Main & Advanced 2026)",
    description: "Intensive 11th + 12th complete syllabus coverage with high-speed problem solving.",
    subjects: [
      {
        name: "Physics",
        faculty: "Rajwant Sir & Saleem Sir",
        chapters: [
          {
            id: "pra-phy-1",
            title: "Mechanics Comprehensive Capsule",
            lectures: [
              { id: "pra-phy-1-1", title: "Lec 01: Kinematics 1D & 2D Rapid Problem Solving", type: "lecture", duration: "2h 15m" },
              { id: "pra-phy-1-2", title: "Lec 02: Newton's Laws & Friction Multi-Block Mastery", type: "lecture", duration: "2h 20m" },
              { id: "pra-phy-1-3", title: "Lec 03: Work, Energy, Power & Vertical Circular Motion", type: "lecture", duration: "2h 10m" },
              { id: "pra-phy-1-dpp1", title: "DPP 01: Advanced Mechanics PYQ Drill", type: "dpp", duration: "1h 00m" }
            ]
          }
        ]
      },
      {
        name: "Chemistry",
        faculty: "Pankaj Sir & Amit Mahajan Sir",
        chapters: [
          {
            id: "pra-chem-1",
            title: "Physical Chemistry Fundamentals",
            lectures: [
              { id: "pra-chem-1-1", title: "Lec 01: Mole Concept, Stoichiometry & Redox Titrations", type: "lecture", duration: "2h 10m" },
              { id: "pra-chem-1-2", title: "Lec 02: Chemical Thermodynamics & Thermochemistry", type: "lecture", duration: "2h 25m" },
              { id: "pra-chem-1-dpp1", title: "DPP 01: Physical Chemistry High-Yield Problems", type: "dpp", duration: "50m" }
            ]
          }
        ]
      },
      {
        name: "Mathematics",
        faculty: "Sachin Sir",
        chapters: [
          {
            id: "pra-math-1",
            title: "Algebra Rapid Revision",
            lectures: [
              { id: "pra-math-1-1", title: "Lec 01: Quadratic Equations & Location of Roots", type: "lecture", duration: "2h 15m" },
              { id: "pra-math-1-2", title: "Lec 02: Complex Numbers Geometry & De Moivre's Theorem", type: "lecture", duration: "2h 30m" },
              { id: "pra-math-1-dpp1", title: "DPP 01: Algebra Advanced Problems", type: "dpp", duration: "1h 00m" }
            ]
          }
        ]
      }
    ]
  },
  {
    id: "manzil-jee-2026",
    name: "Manzil JEE (One-Shot Revision)",
    target: "All JEE Aspirants (High-Yield Marathons)",
    description: "Complete chapter one-shot marathons with theory, shortcuts, and 40+ PYQs per chapter.",
    subjects: [
      {
        name: "Physics",
        faculty: "MR Sir, Rajwant Sir, Saleem Sir",
        chapters: [
          {
            id: "man-phy-1",
            title: "Mechanics One-Shot Marathons",
            lectures: [
              { id: "man-phy-1-1", title: "Kinematics in 1 Shot (Full Theory + 40 PYQs)", type: "lecture", duration: "5h 15m" },
              { id: "man-phy-1-2", title: "Newton's Laws of Motion & Friction in 1 Shot", type: "lecture", duration: "5h 45m" },
              { id: "man-phy-1-3", title: "Rotational Dynamics in 1 Shot Complete Mastery", type: "lecture", duration: "6h 30m" }
            ]
          }
        ]
      },
      {
        name: "Chemistry",
        faculty: "Pankaj Sir, Faisal Sir, Amit Mahajan Sir",
        chapters: [
          {
            id: "man-chem-1",
            title: "Chemistry One-Shot Marathons",
            lectures: [
              { id: "man-chem-1-1", title: "Complete Chemical Bonding in 1 Shot", type: "lecture", duration: "5h 00m" },
              { id: "man-chem-1-2", title: "Complete Organic Chemistry Reaction Mechanisms", type: "lecture", duration: "7h 20m" }
            ]
          }
        ]
      },
      {
        name: "Mathematics",
        faculty: "Sachin Sir, Ashish Agarwal Sir",
        chapters: [
          {
            id: "man-math-1",
            title: "Mathematics One-Shot Marathons",
            lectures: [
              { id: "man-math-1-1", title: "Complete Definite Integration & Area Under Curves in 1 Shot", type: "lecture", duration: "6h 15m" },
              { id: "man-math-1-2", title: "Vectors & 3D Geometry Full Chapter Marathon", type: "lecture", duration: "5h 40m" }
            ]
          }
        ]
      }
    ]
  }
];
function OthersPage() {
  const [location, navigate] = useLocation();
  const [subView, setSubView] = reactExports.useState("hub");
  const [batches, setBatches] = reactExports.useState(DEFAULT_PW_BATCHES);
  const [selectedBatchId, setSelectedBatchId] = reactExports.useState("arjuna-jee-2026");
  const [activeSubject, setActiveSubject] = reactExports.useState("All");
  const [statusFilter, setStatusFilter] = reactExports.useState("all");
  const [lectureSearch, setLectureSearch] = reactExports.useState("");
  const [openChapters, setOpenChapters] = reactExports.useState({});
  const [completedMap, setCompletedMap] = reactExports.useState(() => {
    try {
      const saved = localStorage.getItem("pw_completed_lectures");
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });
  reactExports.useEffect(() => {
    const cdnUrl = "https://cdn.jsdelivr.net/gh/codingwithom/jee-pyq-db@main/pw/batches.json";
    fetch(cdnUrl).then((res) => res.ok ? res.json() : null).then((data) => {
      if (data && data.batches && Array.isArray(data.batches) && data.batches.length > 0) {
        setBatches(data.batches);
      }
    }).catch(() => {
      fetch("/data/pw/batches.json").then((res) => res.ok ? res.json() : null).then((data) => {
        if (data && data.batches && Array.isArray(data.batches)) {
          setBatches(data.batches);
        }
      }).catch(() => {
      });
    });
    idbGet("pw_completed_lectures").then((saved) => {
      if (saved) {
        setCompletedMap((prev) => ({ ...prev, ...saved }));
      }
    }).catch(() => {
    });
  }, []);
  reactExports.useEffect(() => {
    try {
      localStorage.setItem("pw_completed_lectures", JSON.stringify(completedMap));
      idbSet("pw_completed_lectures", completedMap).catch(() => {
      });
    } catch {
    }
  }, [completedMap]);
  reactExports.useEffect(() => {
    if (location === "/others/questions" || location === "/questions") {
      setSubView("questions");
    } else if (location === "/others/pw" || location === "/pw") {
      setSubView("pw");
    } else {
      setSubView("hub");
    }
  }, [location]);
  const currentBatch = reactExports.useMemo(() => {
    return batches.find((b) => b.id === selectedBatchId) || batches[0] || DEFAULT_PW_BATCHES[0];
  }, [batches, selectedBatchId]);
  reactExports.useEffect(() => {
    if (currentBatch && currentBatch.subjects) {
      const initialOpen = {};
      currentBatch.subjects.forEach((sub) => {
        sub.chapters.forEach((ch) => {
          initialOpen[ch.id] = true;
        });
      });
      setOpenChapters(initialOpen);
    }
  }, [currentBatch]);
  const toggleLectureCompletion = (lectureId) => {
    setCompletedMap((prev) => {
      const updated = { ...prev, [lectureId]: !prev[lectureId] };
      return updated;
    });
  };
  const toggleChapter = (chapterId) => {
    setOpenChapters((prev) => ({
      ...prev,
      [chapterId]: !prev[chapterId]
    }));
  };
  const toggleAllInChapter = (chapter) => {
    const allCompleted = chapter.lectures.every((l) => completedMap[l.id]);
    setCompletedMap((prev) => {
      const updated = { ...prev };
      chapter.lectures.forEach((l) => {
        updated[l.id] = !allCompleted;
      });
      return updated;
    });
  };
  const batchStats = reactExports.useMemo(() => {
    let total = 0;
    let completed = 0;
    const subjectStats = {};
    currentBatch.subjects.forEach((sub) => {
      if (!subjectStats[sub.name]) {
        subjectStats[sub.name] = { total: 0, completed: 0 };
      }
      sub.chapters.forEach((ch) => {
        ch.lectures.forEach((l) => {
          total++;
          subjectStats[sub.name].total++;
          if (completedMap[l.id]) {
            completed++;
            subjectStats[sub.name].completed++;
          }
        });
      });
    });
    const percent = total > 0 ? Math.round(completed / total * 100) : 0;
    return { total, completed, percent, subjectStats };
  }, [currentBatch, completedMap]);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-full bg-background text-foreground transition-colors", children: [
    subView === "questions" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card/90 backdrop-blur-md border-b border-border/80 px-4 py-2.5 flex items-center justify-between sticky top-0 z-30 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => {
              setSubView("hub");
              navigate("/others");
            },
            className: "gap-2 text-xs font-semibold rounded-xl hover:bg-muted",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
              "Back to Others Hub"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-primary/10 text-primary border border-primary/20", children: "JEE Main & Advanced PYQ System" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuestionsPage, {})
    ] }),
    subView === "pw" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-6 md:p-8 max-w-6xl mx-auto space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 pb-4 border-b border-border/60", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => {
              setSubView("hub");
              navigate("/others");
            },
            className: "gap-2 text-xs font-semibold rounded-xl",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
              "Back to Others Hub"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-3.5 h-3.5 fill-amber-500 text-amber-500" }),
          "PW Daily Lecture Tracker"
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card border border-border/80 rounded-3xl p-6 sm:p-7 shadow-xs space-y-5", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[11px] font-bold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5 mb-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-3.5 h-3.5 text-amber-500" }),
              "Select Your Physics Wallah Batch"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl font-black text-foreground", children: currentBatch.name }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-muted-foreground mt-0.5", children: [
              currentBatch.target,
              " • ",
              currentBatch.description
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: batches.map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setSelectedBatchId(b.id),
              className: `px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${selectedBatchId === b.id ? "bg-amber-600 text-white shadow-sm shadow-amber-600/30 scale-102" : "bg-muted text-muted-foreground hover:text-foreground hover:bg-muted/80 border border-border/60"}`,
              children: b.name
            },
            b.id
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 rounded-2xl bg-muted/40 border border-border/80 space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "w-4 h-4 text-emerald-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold text-foreground", children: "Batch Progress:" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono font-bold text-emerald-600 dark:text-emerald-400", children: [
                batchStats.completed,
                " / ",
                batchStats.total,
                " Items Completed"
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono font-bold text-base text-foreground", children: [
                batchStats.percent,
                "%"
              ] }),
              batchStats.completed > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: () => {
                    if (window.confirm("Reset all completed checkmarks for this batch?")) {
                      setCompletedMap({});
                    }
                  },
                  className: "text-[11px] text-muted-foreground hover:text-red-500 flex items-center gap-1 transition-colors",
                  title: "Reset completed ticks",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(RotateCcw, { className: "w-3 h-3" }),
                    " Reset"
                  ]
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-2.5 w-full bg-muted rounded-full overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "h-full bg-gradient-to-r from-amber-500 to-emerald-500 rounded-full transition-all duration-500",
              style: { width: `${batchStats.percent}%` }
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2 pt-1 text-[11px]", children: Object.entries(batchStats.subjectStats).map(([subName, stats]) => {
            const subPct = stats.total > 0 ? Math.round(stats.completed / stats.total * 100) : 0;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "px-2.5 py-1 rounded-lg bg-background border border-border/80 flex items-center gap-1.5 shadow-2xs",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-medium text-foreground", children: [
                    subName,
                    ":"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-mono font-bold text-primary", children: [
                    stats.completed,
                    "/",
                    stats.total
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-[10px] text-muted-foreground font-semibold", children: [
                    "(",
                    subPct,
                    "%)"
                  ] })
                ]
              },
              subName
            );
          }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card border border-border/80 rounded-2xl p-4 shadow-xs space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Input,
              {
                type: "text",
                placeholder: "Search lecture, topic, or chapter (e.g. Projectile, Mole)...",
                value: lectureSearch,
                onChange: (e) => setLectureSearch(e.target.value),
                className: "pl-9 h-10 rounded-xl text-xs bg-background border-border"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0", children: ["All", ...currentBatch.subjects.map((s) => s.name)].map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setActiveSubject(sub),
              className: `px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${activeSubject === sub ? "bg-primary text-primary-foreground shadow-xs" : "bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground"}`,
              children: sub
            },
            sub
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2 pt-2 border-t border-border/40 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-[11px] text-muted-foreground", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ListTodo, { className: "w-3.5 h-3.5" }),
            " Filter by Status:"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5", children: [
            { key: "all", label: "All Items" },
            { key: "pending", label: "Pending Only" },
            { key: "completed", label: "Completed" }
          ].map((tab) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setStatusFilter(tab.key),
              className: `px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${statusFilter === tab.key ? "bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold border border-amber-500/30" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`,
              children: tab.label
            },
            tab.key
          )) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4", children: currentBatch.subjects.filter((sub) => activeSubject === "All" || sub.name === activeSubject).map((sub) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-between gap-2 pt-2 pb-1", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-lg font-bold text-foreground flex items-center gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `w-2.5 h-2.5 rounded-full ${sub.name === "Physics" ? "bg-blue-500" : sub.name === "Chemistry" ? "bg-emerald-500" : "bg-purple-500"}` }),
            sub.name,
            sub.faculty && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-xs font-normal text-muted-foreground", children: [
              "• ",
              sub.faculty
            ] })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-3", children: sub.chapters.map((ch) => {
            const filteredLectures = ch.lectures.filter((l) => {
              if (statusFilter === "completed" && !completedMap[l.id]) return false;
              if (statusFilter === "pending" && completedMap[l.id]) return false;
              if (lectureSearch.trim().length > 0) {
                const q = lectureSearch.toLowerCase();
                const match = l.title.toLowerCase().includes(q) || ch.title.toLowerCase().includes(q);
                if (!match) return false;
              }
              return true;
            });
            if (filteredLectures.length === 0 && (lectureSearch.trim().length > 0 || statusFilter !== "all")) {
              return null;
            }
            const isOpen = openChapters[ch.id] ?? true;
            const totalInChapter = ch.lectures.length;
            const completedInChapter = ch.lectures.filter((l) => completedMap[l.id]).length;
            const isChapterComplete = totalInChapter > 0 && completedInChapter === totalInChapter;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              Card,
              {
                className: `rounded-2xl border transition-all overflow-hidden ${isChapterComplete ? "border-emerald-500/40 bg-emerald-50/20 dark:bg-emerald-950/10" : "border-border/80 bg-card"}`,
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "div",
                    {
                      onClick: () => toggleChapter(ch.id),
                      className: "p-4 sm:p-4.5 flex items-center justify-between gap-3 cursor-pointer hover:bg-muted/40 select-none transition-colors",
                      children: [
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3 min-w-0 flex-1", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${isChapterComplete ? "bg-emerald-500 text-white shadow-xs" : "bg-muted text-muted-foreground"}`, children: isChapterComplete ? /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-4 h-4 stroke-[3]" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(BookOpen, { className: "w-4 h-4" }) }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-w-0 flex-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm sm:text-base font-bold text-foreground truncate", children: ch.title }),
                            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] text-muted-foreground", children: [
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
                                completedInChapter,
                                " of ",
                                totalInChapter,
                                " completed"
                              ] }),
                              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                              /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "font-semibold text-primary", children: [
                                Math.round(completedInChapter / totalInChapter * 100),
                                "%"
                              ] })
                            ] })
                          ] })
                        ] }),
                        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsx(
                            "button",
                            {
                              type: "button",
                              onClick: (e) => {
                                e.stopPropagation();
                                toggleAllInChapter(ch);
                              },
                              className: "px-2.5 py-1 rounded-lg text-[11px] font-semibold border border-border/80 bg-background hover:bg-muted text-muted-foreground hover:text-foreground transition-all",
                              title: "Mark all items in this chapter as done",
                              children: isChapterComplete ? "Uncheck All" : "Mark All"
                            }
                          ),
                          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-1 text-muted-foreground", children: isOpen ? /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-4 h-4" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-4 h-4" }) })
                        ] })
                      ]
                    }
                  ),
                  isOpen && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-border/60 divide-y divide-border/40 bg-muted/10", children: filteredLectures.map((lec) => {
                    const isChecked = Boolean(completedMap[lec.id]);
                    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
                      "div",
                      {
                        onClick: () => toggleLectureCompletion(lec.id),
                        className: `p-3.5 sm:px-5 flex items-center justify-between gap-3 cursor-pointer transition-colors ${isChecked ? "bg-emerald-50/40 dark:bg-emerald-950/20 text-muted-foreground" : "hover:bg-muted/30 text-foreground"}`,
                        children: [
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3.5 min-w-0 flex-1", children: [
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all ${isChecked ? "bg-emerald-600 border-emerald-600 text-white shadow-2xs" : "border-border/80 bg-background hover:border-primary"}`, children: isChecked && /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "w-3.5 h-3.5 stroke-[3]" }) }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "min-w-0 flex-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: `text-xs sm:text-sm font-medium leading-tight ${isChecked ? "line-through opacity-75" : ""}`, children: lec.title }) })
                          ] }),
                          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 shrink-0", children: [
                            lec.duration && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[11px] font-mono text-muted-foreground hidden sm:inline-block", children: lec.duration }),
                            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-2 py-0.5 rounded-md text-[10px] font-bold uppercase tracking-wider ${lec.type === "dpp" ? "bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20" : "bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20"}`, children: lec.type })
                          ] })
                        ]
                      },
                      lec.id
                    );
                  }) })
                ]
              },
              ch.id
            );
          }) })
        ] }, sub.name);
      }) })
    ] }),
    subView === "hub" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-6 md:p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-3.5 h-3.5" }),
          "Learning Hub & Utilities"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-foreground", children: "Others & Resources" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground max-w-2xl leading-relaxed", children: "Select a module below to practice official JEE Main & Advanced previous year questions or track your daily Physics Wallah lectures and DPP syllabus progress." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              setSubView("questions");
              navigate("/others/questions");
            },
            className: "relative overflow-hidden rounded-3xl border border-border/80 bg-card p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-primary/50 transition-all cursor-pointer group flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/15 transition-all" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileQuestionMark, { className: "w-7 h-7 stroke-[2.2]" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20", children: "14,183+ Verified PYQs" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl sm:text-2xl font-black text-foreground group-hover:text-primary transition-colors flex items-center gap-2", children: [
                    "1. JEE Questions",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-primary" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground leading-relaxed", children: "Official JEE Main & JEE Advanced practice with paper-wise shifts, chapter-wise filters, CBT numerical keypads, and step-by-step LaTeX derivations." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "JEE Main 2010–2026" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "JEE Advanced Papers" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "172 Chapters" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Zero Delay 0ms CDN" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-6 mt-6 border-t border-border/60 flex items-center justify-between relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-muted-foreground group-hover:text-foreground transition-colors", children: "Tap to launch Question Practice" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "rounded-xl font-bold text-xs gap-2 py-4 px-5 shadow-sm group-hover:shadow-md transition-all", children: [
                  "Open Questions ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              setSubView("pw");
              navigate("/others/pw");
            },
            className: "relative overflow-hidden rounded-3xl border border-border/80 bg-card p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-amber-500/50 transition-all cursor-pointer group flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl group-hover:bg-amber-500/15 transition-all" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-7 h-7 fill-amber-500 text-amber-500" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20", children: "Daily Lecture Tracker" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl sm:text-2xl font-black text-foreground group-hover:text-amber-500 transition-colors flex items-center gap-2", children: [
                    "2. PW (Physics Wallah)",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-amber-500" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground leading-relaxed", children: "Select your batch (Arjuna, Lakshya, Prayas, Manzil) and tick off lectures and DPPs as you complete them to track your daily syllabus completion." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Arjuna & Lakshya" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Prayas Dropper" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Interactive Ticks" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Auto-Sync CDN" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-6 mt-6 border-t border-border/60 flex items-center justify-between relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-muted-foreground group-hover:text-foreground transition-colors", children: "Tap to track PW Batches & Lectures" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "rounded-xl font-bold text-xs gap-2 py-4 px-5 bg-amber-600 hover:bg-amber-700 text-white shadow-sm group-hover:shadow-md transition-all", children: [
                  "Open PW Tracker ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                ] })
              ] })
            ]
          }
        )
      ] })
    ] })
  ] });
}
export {
  OthersPage as default
};
