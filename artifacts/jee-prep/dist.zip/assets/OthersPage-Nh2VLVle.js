import { aK as useLocation, r as reactExports, j as jsxRuntimeExports, B as Button, y as ArrowLeft, az as Sparkles, S as Search, I as Input, C as Card, z as FileText, aL as Video, aM as Atom, a6 as Layers } from "./index-BJgviARh.js";
import { Q as QuestionsPage, S as SlidersHorizontal, F as FileQuestionMark } from "./QuestionsPage-8h2ldWT2.js";
import { F as Flame } from "./flame-eMKX-a9H.js";
import { Z as Zap } from "./zap-Dnrdc0a8.js";
import { A as ArrowRight } from "./katex-e8fuJ3jf.js";
import "./circle-alert-BJvkPv72.js";
import "./rotate-ccw-DuYYAYor.js";
import "./clock-CKHNHUAS.js";
import "./circle-check-DGUxpDGn.js";
const PW_RESOURCES = [
  // Physics Resources
  {
    id: "pw-phy-1",
    title: "Mechanics & Kinematics High-Yield Mind Map",
    subject: "Physics",
    batch: "Manzil",
    category: "Mind Map",
    faculty: "Rajwant Sir",
    chapter: "Kinematics & Laws of Motion",
    durationOrPages: "14 Pages",
    description: "Complete formula chart, projectile motion shortcuts, and constrained motion pulley tricks.",
    type: "pdf"
  },
  {
    id: "pw-phy-2",
    title: "Electrodynamics & Gauss Law Super Notes",
    subject: "Physics",
    batch: "Lakshya",
    category: "Notes",
    faculty: "Saleem Sir",
    chapter: "Electrostatics & Capacitance",
    durationOrPages: "28 Pages",
    description: "Detailed derivations for electric field, potential distributions, capacitor dielectric combinations, and boundary conditions.",
    type: "pdf"
  },
  {
    id: "pw-phy-3",
    title: "Rotational Motion Advanced DPP with Solutions",
    subject: "Physics",
    batch: "Prayas",
    category: "DPP",
    faculty: "Rajwant Sir",
    chapter: "Rotational Dynamics",
    durationOrPages: "25 Questions",
    description: "High-level problems on moment of inertia, rolling without slipping, and angular momentum conservation.",
    type: "practice"
  },
  {
    id: "pw-phy-4",
    title: "Current Electricity & Circuits One-Shot Marathon",
    subject: "Physics",
    batch: "Manzil",
    category: "One-Shot Lecture",
    faculty: "MR Sir",
    chapter: "Current Electricity",
    durationOrPages: "4h 15m",
    description: "Complete revision covering Kirchhoff rules, potentiometer, meter bridge, RC transient circuits with 30+ PYQs.",
    type: "video"
  },
  {
    id: "pw-phy-5",
    title: "Modern Physics & Dual Nature Complete Formula Book",
    subject: "Physics",
    batch: "All",
    category: "Formula Book",
    faculty: "Rajwant Sir",
    chapter: "Modern Physics",
    durationOrPages: "10 Pages",
    description: "Photoelectric equation, de Broglie wavelength, Bohr model transitions, and nuclear decay kinetics formulas.",
    type: "pdf"
  },
  // Chemistry Resources
  {
    id: "pw-chem-1",
    title: "Organic Chemistry All Reagents & Reaction Mechanisms",
    subject: "Chemistry",
    batch: "Manzil",
    category: "Formula Book",
    faculty: "Pankaj Sir",
    chapter: "Complete Organic Chemistry",
    durationOrPages: "36 Pages",
    description: "Comprehensive chart of oxidizing & reducing agents, Grignard reagents, named reactions (Aldol, Cannizzaro, Sandmeyer).",
    type: "pdf"
  },
  {
    id: "pw-chem-2",
    title: "Chemical Bonding & Molecular Orbital Theory (MOT) Notes",
    subject: "Chemistry",
    batch: "Arjuna",
    category: "Notes",
    faculty: "Amit Mahajan Sir",
    chapter: "Chemical Bonding",
    durationOrPages: "22 Pages",
    description: "VSEPR geometries, dipole moment comparison, bond order calculation tricks, and hydrogen bonding anomalies.",
    type: "pdf"
  },
  {
    id: "pw-chem-3",
    title: "Thermodynamics & Thermochemistry Advanced DPP",
    subject: "Chemistry",
    batch: "Prayas",
    category: "DPP",
    faculty: "Faisal Sir",
    chapter: "Thermodynamics",
    durationOrPages: "30 Questions",
    description: "Problems on state functions, enthalpy calculations, entropy criteria, Gibbs free energy spontaneity, and Hess law.",
    type: "practice"
  },
  {
    id: "pw-chem-4",
    title: "Coordination Compounds & CFT One-Shot Marathon",
    subject: "Chemistry",
    batch: "Manzil",
    category: "One-Shot Lecture",
    faculty: "Amit Mahajan Sir",
    chapter: "Coordination Chemistry",
    durationOrPages: "3h 45m",
    description: "Crystal field splitting, color and magnetic moment, isomerism (optical & geometrical), and Werner theory.",
    type: "video"
  },
  {
    id: "pw-chem-5",
    title: "Inorganic Chemistry NCERT High-Yield Line-by-Line Mind Map",
    subject: "Chemistry",
    batch: "All",
    category: "Mind Map",
    faculty: "Pankaj Sir",
    chapter: "d- and f-Block Elements & p-Block",
    durationOrPages: "18 Pages",
    description: "Key trends in oxidation states, catalytic properties, interstitial compounds, and potassium dichromate / permanganate reactions.",
    type: "pdf"
  },
  // Mathematics Resources
  {
    id: "pw-math-1",
    title: "Definite Integration & Area Under Curves Master Notes",
    subject: "Mathematics",
    batch: "Lakshya",
    category: "Notes",
    faculty: "Sachin Sir",
    chapter: "Definite Integrals & AUC",
    durationOrPages: "32 Pages",
    description: "King property, Leibniz rule, periodicity properties, reduction formulas, and tricky area enclosed calculations.",
    type: "pdf"
  },
  {
    id: "pw-math-2",
    title: "Coordinate Geometry (Conics & Circles) All Formulae Chart",
    subject: "Mathematics",
    batch: "Manzil",
    category: "Formula Book",
    faculty: "Ashish Agarwal Sir",
    chapter: "Circles, Parabola, Ellipse, Hyperbola",
    durationOrPages: "16 Pages",
    description: "Standard equations, tangents, normals, director circles, auxiliary circles, and focal distance properties.",
    type: "pdf"
  },
  {
    id: "pw-math-3",
    title: "Vectors & 3D Geometry Advanced Practice DPP",
    subject: "Mathematics",
    batch: "Prayas",
    category: "DPP",
    faculty: "Sachin Sir",
    chapter: "Vector Algebra & 3D Geometry",
    durationOrPages: "25 Questions",
    description: "Scalar and vector triple products, shortest distance between skew lines, coplanarity, and projection problems.",
    type: "practice"
  },
  {
    id: "pw-math-4",
    title: "Calculus (Differential & Integral) Marathon Revision",
    subject: "Mathematics",
    batch: "Manzil",
    category: "One-Shot Lecture",
    faculty: "Sachin Sir",
    chapter: "Differential Calculus",
    durationOrPages: "5h 20m",
    description: "Continuity, differentiability, Rolle's & LMVT theorems, tangents and normals, maxima and minima with JEE Advanced PYQs.",
    type: "video"
  },
  {
    id: "pw-math-5",
    title: "Matrices & Determinants Rapid Mind Map",
    subject: "Mathematics",
    batch: "Arjuna",
    category: "Mind Map",
    faculty: "Ashish Sir",
    chapter: "Matrices & Determinants",
    durationOrPages: "8 Pages",
    description: "System of linear equations (Cramer's rule), adjoint and inverse properties, Cayley-Hamilton theorem, and special matrices.",
    type: "pdf"
  }
];
function OthersPage() {
  const [location, navigate] = useLocation();
  const [subView, setSubView] = reactExports.useState("hub");
  const [pwSubject, setPwSubject] = reactExports.useState("All");
  const [pwBatch, setPwBatch] = reactExports.useState("All");
  const [pwCategory, setPwCategory] = reactExports.useState("All");
  const [pwSearch, setPwSearch] = reactExports.useState("");
  reactExports.useEffect(() => {
    if (location === "/others/questions" || location === "/questions") {
      setSubView("questions");
    } else if (location === "/others/pw" || location === "/pw") {
      setSubView("pw");
    } else {
      setSubView("hub");
    }
  }, [location]);
  const filteredPwResources = PW_RESOURCES.filter((res) => {
    if (pwSubject !== "All" && res.subject !== pwSubject) return false;
    if (pwBatch !== "All" && res.batch !== pwBatch && res.batch !== "All") return false;
    if (pwCategory !== "All" && res.category !== pwCategory) return false;
    if (pwSearch.trim().length > 0) {
      const q = pwSearch.toLowerCase();
      const match = res.title.toLowerCase().includes(q) || res.chapter.toLowerCase().includes(q) || res.faculty && res.faculty.toLowerCase().includes(q) || res.description.toLowerCase().includes(q);
      if (!match) return false;
    }
    return true;
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-full bg-background text-foreground transition-colors", children: [
    subView === "questions" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-card/90 backdrop-blur-md border-b border-border/80 px-4 py-2.5 flex items-center justify-between sticky top-0 z-30 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "ghost",
            size: "sm",
            onClick: () => {
              setSubView("hub");
              navigate("/others");
            },
            className: "gap-2 text-xs font-semibold rounded-xl hover:bg-muted",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
              "Back to Others"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-primary/10 text-primary border border-primary/20", children: "JEE Main & Advanced PYQ System" }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(QuestionsPage, {})
    ] }),
    subView === "pw" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-6 md:p-8 max-w-7xl mx-auto space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-4 pb-4 border-b border-border/60", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => {
              setSubView("hub");
              navigate("/others");
            },
            className: "gap-2 text-xs font-semibold rounded-xl",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4" }),
              "Back to Others Hub"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20 flex items-center gap-1.5", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-3.5 h-3.5 fill-amber-500 text-amber-500" }),
          "Physics Wallah (PW) Portal"
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500/15 via-primary/10 to-purple-500/10 border border-amber-500/20 p-6 sm:p-8", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative z-10 max-w-2xl space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-background/80 backdrop-blur-md border border-border/60 text-xs font-bold text-foreground shadow-2xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Sparkles, { className: "w-3.5 h-3.5 text-amber-500" }),
          "Complete PW Study Ecosystem"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-foreground", children: [
          "Physics Wallah ",
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "bg-gradient-to-r from-amber-500 to-orange-500 bg-clip-text text-transparent", children: "JEE Vault" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground leading-relaxed", children: "Curated lecture notes, Daily Practice Problems (DPP), formula cheat sheets, and marathon one-shots from Lakshya, Prayas, Arjuna, and Manzil batches." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3 bg-card border border-border/80 rounded-2xl p-4 shadow-xs", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative flex-1 max-w-md", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Input,
              {
                type: "text",
                placeholder: "Search PW notes, chapters, faculty (e.g. Rajwant, Calculus)...",
                value: pwSearch,
                onChange: (e) => setPwSearch(e.target.value),
                className: "pl-9 h-10 rounded-xl text-xs bg-background border-border"
              }
            )
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0", children: ["All", "Physics", "Chemistry", "Mathematics"].map((sub) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setPwSubject(sub),
              className: `px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${pwSubject === sub ? "bg-primary text-primary-foreground shadow-xs" : "bg-muted hover:bg-muted/80 text-muted-foreground hover:text-foreground"}`,
              children: sub
            },
            sub
          )) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap items-center gap-2 pt-2 border-t border-border/40 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-muted-foreground font-medium text-[11px] flex items-center gap-1 mr-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(SlidersHorizontal, { className: "w-3 h-3" }),
            " Batch:"
          ] }),
          ["All", "Manzil", "Lakshya", "Prayas", "Arjuna"].map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setPwBatch(b),
              className: `px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${pwBatch === b ? "bg-amber-500/20 text-amber-700 dark:text-amber-300 font-bold border border-amber-500/30" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`,
              children: b
            },
            b
          )),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-muted-foreground font-medium text-[11px] flex items-center gap-1 ml-auto mr-1", children: "Category:" }),
          ["All", "DPP", "Notes", "Formula Book", "Mind Map", "One-Shot Lecture"].map((cat) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setPwCategory(cat),
              className: `px-2.5 py-1 rounded-lg text-[11px] font-medium transition-all ${pwCategory === cat ? "bg-purple-500/20 text-purple-700 dark:text-purple-300 font-bold border border-purple-500/30" : "text-muted-foreground hover:text-foreground hover:bg-muted"}`,
              children: cat
            },
            cat
          ))
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4", children: filteredPwResources.map((res) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Card,
        {
          className: "p-5 rounded-2xl border-border/80 bg-card hover:border-primary/40 hover:shadow-md transition-all flex flex-col justify-between group",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between gap-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: `px-2.5 py-0.5 rounded-full text-[10px] font-bold ${res.subject === "Physics" ? "bg-blue-500/10 text-blue-600 dark:text-blue-400 border border-blue-500/20" : res.subject === "Chemistry" ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20" : "bg-purple-500/10 text-purple-600 dark:text-purple-400 border border-purple-500/20"}`, children: res.subject }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1.5", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md text-[10px] font-bold bg-muted text-muted-foreground", children: res.batch }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2 py-0.5 rounded-md text-[10px] font-semibold bg-primary/5 text-primary border border-primary/20", children: res.category })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-foreground group-hover:text-primary transition-colors line-clamp-2", children: res.title }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[11px] text-muted-foreground mt-1 line-clamp-2 leading-relaxed", children: res.description })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-4 mt-3 border-t border-border/60 flex items-center justify-between text-xs", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-[11px] text-muted-foreground", children: [
                res.faculty && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-medium text-foreground", children: res.faculty }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "•" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: res.durationOrPages })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  size: "sm",
                  variant: "outline",
                  onClick: () => {
                    if (res.type === "pdf") {
                      navigate("/pdf");
                    } else if (res.type === "video") {
                      navigate("/video");
                    } else {
                      setSubView("questions");
                    }
                  },
                  className: "h-8 px-3 rounded-lg text-xs gap-1.5 font-semibold group-hover:bg-primary group-hover:text-primary-foreground group-hover:border-primary transition-all",
                  children: res.type === "pdf" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(FileText, { className: "w-3.5 h-3.5" }),
                    " View PDF"
                  ] }) : res.type === "video" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Video, { className: "w-3.5 h-3.5" }),
                    " Watch"
                  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Zap, { className: "w-3.5 h-3.5" }),
                    " Practice"
                  ] })
                }
              )
            ] })
          ]
        },
        res.id
      )) }),
      filteredPwResources.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-12 text-center rounded-2xl border border-dashed border-border/80 bg-muted/10 space-y-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Atom, { className: "w-10 h-10 text-muted-foreground/40 mx-auto" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-bold text-foreground", children: "No resources match your filters" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-muted-foreground max-w-sm mx-auto", children: "Try resetting your subject, batch, or search keyword to see more Physics Wallah resources." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => {
              setPwSubject("All");
              setPwBatch("All");
              setPwCategory("All");
              setPwSearch("");
            },
            className: "rounded-xl text-xs",
            children: "Reset All Filters"
          }
        )
      ] })
    ] }),
    subView === "hub" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 sm:p-6 md:p-8 max-w-6xl mx-auto space-y-8 animate-in fade-in duration-300", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-xs font-bold", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-3.5 h-3.5" }),
          "Learning Hub & Utilities"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl sm:text-3xl md:text-4xl font-black tracking-tight text-foreground", children: "Others & Resources" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground max-w-2xl leading-relaxed", children: "Select a module below to practice official JEE Main & Advanced previous year questions or access complete Physics Wallah study vaults." })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              setSubView("questions");
              navigate("/others/questions");
            },
            className: "relative overflow-hidden rounded-3xl border border-border/80 bg-card p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-primary/50 transition-all cursor-pointer group flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-48 h-48 bg-primary/5 rounded-full blur-3xl group-hover:bg-primary/15 transition-all" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(FileQuestionMark, { className: "w-7 h-7 stroke-[2.2]" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/20", children: "14,183+ Verified PYQs" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl sm:text-2xl font-black text-foreground group-hover:text-primary transition-colors flex items-center gap-2", children: [
                    "1. JEE Questions",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-primary" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground leading-relaxed", children: "Official JEE Main & JEE Advanced practice with paper-wise shifts, chapter-wise filters, CBT numerical keypads, and step-by-step LaTeX derivations." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "JEE Main 2010–2026" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "JEE Advanced Papers" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "172 Chapters" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Zero Delay 0ms CDN" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-6 mt-6 border-t border-border/60 flex items-center justify-between relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-muted-foreground group-hover:text-foreground transition-colors", children: "Tap to launch Question Practice" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "rounded-xl font-bold text-xs gap-2 py-4 px-5 shadow-sm group-hover:shadow-md transition-all", children: [
                  "Open Questions ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                ] })
              ] })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            onClick: () => {
              setSubView("pw");
              navigate("/others/pw");
            },
            className: "relative overflow-hidden rounded-3xl border border-border/80 bg-card p-6 sm:p-8 shadow-sm hover:shadow-xl hover:border-amber-500/50 transition-all cursor-pointer group flex flex-col justify-between",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl group-hover:bg-amber-500/15 transition-all" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-5 relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-14 h-14 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-600 dark:text-amber-400 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Flame, { className: "w-7 h-7 fill-amber-500 text-amber-500" }) }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-600 dark:text-amber-400 border border-amber-500/20", children: "Batches & Notes" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("h2", { className: "text-xl sm:text-2xl font-black text-foreground group-hover:text-amber-500 transition-colors flex items-center gap-2", children: [
                    "2. PW (Physics Wallah)",
                    /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all text-amber-500" })
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs sm:text-sm text-muted-foreground leading-relaxed", children: "Exclusive Physics Wallah study materials, Daily Practice Problems (DPP), Lakshya, Prayas, Arjuna, and Manzil one-shot revision marathon notes." })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-2 pt-2", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Lakshya & Prayas" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Manzil Series" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "DPP Sheets & Solutions" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "px-2.5 py-1 rounded-lg text-xs font-semibold bg-muted text-foreground border border-border/60", children: "Faculty Mind Maps" })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-6 mt-6 border-t border-border/60 flex items-center justify-between relative z-10", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-bold text-muted-foreground group-hover:text-foreground transition-colors", children: "Tap to explore PW Resources" }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs(Button, { className: "rounded-xl font-bold text-xs gap-2 py-4 px-5 bg-amber-600 hover:bg-amber-700 text-white shadow-sm group-hover:shadow-md transition-all", children: [
                  "Open PW Hub ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4" })
                ] })
              ] })
            ]
          }
        )
      ] })
    ] })
  ] });
}
export {
  OthersPage as default
};
